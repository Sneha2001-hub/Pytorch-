# Sentiment Analysis using PyTorch

This is a simple Sentiment Analysis project using PyTorch. It classifies text as **positive** or **negative**.

## 🚀 Installation

1. Clone the repository:

   ```bash
   git clone https://github.com/yourusername/sentiment-analysis.git
   cd sentiment-analysis
   ```

2. Install dependencies:

   ```bash
   pip install torch torchvision torchtext
   ```

## 🏋️‍♂️ Training the Model

Run the training script:

```bash
python sentiment_analysis.py
```

## 📄 Model Output

After training, the model will be saved as `sentiment_model.pth`.
